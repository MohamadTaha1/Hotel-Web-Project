<footer>
        <h1 class="hfoot"><br> Crown Palace </h1>
        <div style = "display: flex; justify-content: center;">
           <ul class = "footul">
                <li class = "ul-li-foot"> Hotel 
                    <ul class="xul"><li><a class = "axli" href = "Sleep.php"><i class="fa fa-bed"> </i> &nbsp;Rooms</a> </li>
                    <li><a class = "axli" href = "Services.php"><i class="fa fa-briefcase" > </i> &nbsp;Services </a> </li>
                    <li><a class = "axli" href = "Restaurant.php"><i class="fa fa-cutlery"> </i>&nbsp;  Restaurant </a></li>
                    <li><a class = "axli" href = "contactUs.php#this"><i class="fa fa-at"></i>&nbsp; Contact Us</a></li>
                       </ul>
                </li>
                
                <li class = "ul-li-foot"> Customer Help
                    <ul class="xul"> <li><a class = "axli" href = "#aboutUs"> <i class="fa fa-info"> </i> &nbsp;About Us</a> </li>
                    <li><a class = "axli" href = "review.php#r"> <i class="fa fa-pencil-square-o"> </i> &nbsp;Reviews</a></li>
                     <li><a class = "axli" href = "https://maps.app.goo.gl/skkVUX2YDr3F5xEz8?g_st=iw"><i class="fa fa-road"></i> &nbsp; Directions</a></li>
                     <li><a class = "axli" href = "faq.php#Faq"><i class="fa fa-question-circle"> </i>&nbsp; FAQS </a></li>
                       </ul>
                    </li>
                <li class = "ul-li-foot" href = "contactUs.php#this"> Contact 
                <p class="axli"><i class="fa fa-map-marker"></i>&nbsp; Emille edde Road, Hamra,<br> Beirut, Lebanon</p>
                <p class="axli"><i class="fa fa-phone-square"></i> &nbsp;+96179175075</p>
                <p class="axli"><i class="fa fa-envelope-o"></i>&nbsp; info@CrownPalace.com</p>
                </li>
            </ul>
        </div>
        
        <div style = "text-align: center">
             <ul class="socials">
                <li class="liSocial"><a href="https://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
                <li class="liSocial"><a href="https://www.Twitter.com"><i class="fa fa-twitter"></i></a></li>
                <li class="liSocial"><a href="https://www.gmail.com"><i class="fa fa-google-plus"></i></a></li>
                <li class="liSocial"><a href="https://www.youtube.com"><i class="fa fa-youtube"></i></a></li>
                <li class="liSocial"><a href="https://www.linkedin.com"><i class="fa fa-linkedin-square"></i></a></li>
            </ul>
        
        </div>
           
        <div class = "copy">
            Copyright &copy; 2022 Crown Palace.Inc
        </div>
    </footer>