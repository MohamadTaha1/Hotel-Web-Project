<?php
session_start();
$loggedIn = false;


if (isset($_SESSION['username'])){
    $loggedIn = true;
}


if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("Location: HomePage.php");
    die();
}
?>