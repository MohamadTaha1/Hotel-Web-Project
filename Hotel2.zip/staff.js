function Delete(count){

 document.getElementById("row"+count+"").outerHTML="";
}


function Edit(count){

    var status=document.getElementById("status"+count);
  if(status.innerHTML=="pending")
    status.innerHTML="done";
   
   }

   function DeleteM(count){

    document.getElementById("rowM"+count+"").outerHTML="";
   }
   
   
   function EditM(count){
   
       var status=document.getElementById("statusM"+count);
     if(status.innerHTML=="pending")
       status.innerHTML="done";
      
      }
/* 
function Update(count){
    var current = new Date();
    
    var date = document.getElementById("date"+count);
    

    var dayNow = current.getDate();
    var monthNow = current.getMonth()+1;
    var yearNow = current.getFullYear();

    var dateArray = date.innerHTML.split("/");

    date.innerHTML = monthNow+"/"+dayNow+"/"+yearNow;

   if(monthNow==dateArray[0]){
        console.log(monthNow-dateArray[0]);
      
        if(dayNow-dateArray[1]<1){
            date.style.backgroundColor="red";

        }
    }
   
    }*/

    function addMaintenance(){
        addBtn = document.getElementById("addMaintenance");
        
        location = document.getElementById("location");
        type = document.getElementById("type");
        tabletask = document.getElementById("maintenancetable");
    
        taskBtn.addEventListener("click",tasks)
    
        function tasks(){
            var row1 = document.createElement("tr");
            
            var newempId = document.createElement("td");
            newempId.innerHTML = empId.value;
    
            
            var newshift = document.createElement("td");
            newshift.innerHTML = shift.value;
    
            var newday = document.createElement("td");
            newday.innerHTML = day.value;
    
           
            tabletask.appendChild(row1);
            row1.appendChild(location);
            row1.appendChild(type)
          
    
        }
    }

    function add_row()
   {
    var new_location=document.getElementById("new_location").value;
    var new_type=document.getElementById("new_type").value;
    var new_status=document.getElementById("new_status").value;
   
   
       
    var table=document.getElementById("maintenancetable");
    var table_len=(table.rows.length)-1;
    var row = table.insertRow(table_len).outerHTML=
        "<tr id='row"+table_len+
           "'><td id='roomId"+table_len+"'>"+new_location+
           "</td><td id='type"+table_len+"'>"+new_type+
           "</td><td id='status"+table_len+"'>"+new_status+
           "</td><td><input type='button' id='editMbutton"+table_len+
           "' value='Done' class='edit' onclick='Edit("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='Delete("+table_len+
        ")'></td></tr>";
   
  
   
   }