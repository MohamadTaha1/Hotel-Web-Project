<?php
        include "./base.php";

        

        $json = file_get_contents('php://input');
        
        $data = json_decode($json);
        require 'vendor/autoload.php';

        use MongoDB\Client;
        use MongoDB\Driver\Manager;


        $client = new MongoDB\Client(
            'mongodb+srv://mhmd:taha@cluster0.lary2hg.mongodb.net/?retryWrites=true&w=majority');
        
        $collection = $client->Hotel->Room;

       
        $counterFamily = 0;
        $counterTwin = 0;
        $counterDeluxe = 0;
        $counterKing = 0;

        for($i = 1; $i < 6; $i++){
              
         $result1 = $collection->findOne(["room_id"=>"$i", "dates"=>array('$in'=> $data->DateList)]);
         if($result1){
            $counterFamily+=1;
         }
        
       }

       for($i = 6; $i < 21; $i++){
              
        $result1 = $collection->findOne(["room_id"=>"$i", "dates"=>array('$in'=> $data->DateList)]);
        if($result1){
           $counterTwin+=1;
        }
       
      }

      for($i = 21; $i < 36; $i++){
              
        $result1 = $collection->findOne(["room_id"=>"$i", "dates"=>array('$in'=> $data->DateList)]);
        if($result1){
           $counterDeluxe+=1;
        }
       
      }

      for($i = 36; $i < 51; $i++){
         
        $result1 = $collection->findOne(["room_id"=>"$i", "dates"=>array('$in'=> $data->DateList)]);
        if($result1){
           $counterKing+=1;

        }
       
      }

      $counters = Array();
      $counters[0] = 5 - $counterFamily;
      $counters[1] = 15 - $counterTwin;
      $counters[2]= 15 - $counterDeluxe;
      $counters[3] = 15 - $counterKing;






    #   $_SESSION["result3"] = $counters[0] . " " . $counters[1] . " " . $counters[2] . " " . $counters[3] . " " ;

        $counters = [ "Family"=> $counters[0] ,"Twin"=> $counters[1], "Deluxe"=>  $counters[2], "King"=>  $counters[3]];
       
        $encodedCounters = json_encode($counters);
        $decodedCounters = json_decode($encodedCounters);

        $data_results = file_get_contents('availableRooms.json');
        $tempArray = json_decode($data_results, true);
        
        
       # $jsonCounter = json_decode($jsonCounter,true);
        
        $tempArray[0] = $decodedCounters;
        
        $jsonData = json_encode($tempArray);

        

         file_put_contents('availableRooms.json', $jsonData);
        
      ?>