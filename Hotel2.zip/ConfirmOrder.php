<?php include 'base.php';

require 'vendor/autoload.php';

use MongoDB\Client;
use MongoDB\Driver\Manager;


$client = new MongoDB\Client('mongodb+srv://mhmd:taha@cluster0.lary2hg.mongodb.net/?retryWrites=true&w=majority');

$collection = $client->Hotel->Dish;

if(isset($_POST["submitOrder"])){
$total=0;
for($i = 1; $i<13; $i++){
$dish = $_POST["$i"];
if($dish > 0){
$price = $collection->findOne(["id"=>"$i"], ["projection" => array("price" => 1)]);


$total += (integer)$price["price"] * (integer)$dish;


}

}

$_SESSION["orderPrice"] = $total;

header("Location: payment.php#pay");

}



?>

