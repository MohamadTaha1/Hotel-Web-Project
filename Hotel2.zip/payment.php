<?php 

include '.\base.php';
include '.\SessionSecurity.php';

require 'vendor/autoload.php';

use MongoDB\Client;
use MongoDB\Driver\Manager;


$client = new MongoDB\Client('mongodb+srv://mhmd:taha@cluster0.lary2hg.mongodb.net/?retryWrites=true&w=majority');

$username = $_SESSION["username"];

//echo $_SESSION["orderPrice"];
$errors = array();
if(isset($_POST["submit"])){

  $cardnumber = $_POST["cardnumber"];
  $cardname = $_POST["cardname"];
  $expmonth = $_POST["expmonth"];
  $expyear = $_POST["expyear"];
  $pin = $_POST["pin"];

  if(!preg_match("/^[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}$/",$cardnumber)){
    $errors[] = "Invalid card number";
  }

  if(!preg_match("/^[0-9]{4}$/", $pin)){
    $errors[] = "Invalid pin number";
  }

  if(!preg_match("/^[0-9]{4}$/", $expyear)){
    $errors[] = "Invalid Expiry Year";
  }

  if($expyear < date("Y")){
    $errors[] = "Your card is expired";
  }

  else{

    if($expyear == date("Y")){

    if($expmonth < date("m")){
          $errors[] = "Your card is expired";
  }
}
  }
 
  if(empty($errors)){
    if(isset($_SESSION["orderPrice"]) || $_SESSION["bookPrice"]){
      $collection1 = $client->Hotel->Payment;
      $result = $collection1->findOne(["username" => "$username", "cardNumber" => "$cardnumber", 
    "cardName" => "$cardname", "expMonth" => "$expmonth", "expYear" => "$expyear"]);
      if(!$result){
        $result = $collection1->insertOne(["username" => "$username", "cardNumber" => "$cardnumber", 
    "cardName" => "$cardname", "expMonth" => "$expmonth", "expYear" => "$expyear"]);
      }
    }


    if(isset($_SESSION["orderPrice"])){
      $orderPrice = $_SESSION["orderPrice"];
      $collection1 = $client->Hotel->orderInvioce;
      $result = $collection1->insertOne(["total" => "$orderPrice", "username" => "$username"]);
    }


    if(isset($_SESSION["bookPrice"])){
      echo $_SESSION["bookPrice"];

    }





  }







};
  
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="payment.css">
    <script src="book.js"> </script>
    <title>Home Page</title>
</head>
<body>
   
    
<?php include './nav.php'?>

   <div id = "pay" style="position: absolute; top:75%;"> </div>
   
   <div> 
    <?php
    foreach($errors as $error){
    echo "<div> $error </div>";
    }
    ?> 
    </div>

    <div class="container">
      <form action="#" method="post" style="display: flex;">
      
          <div class = "divv">
           
            <h3 >Billing Address</h3>
            <label><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="Fname" name="firstname" placeholder="Khaleel Mershad">
            
            <label><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="khalil@example.com">
            
            <label><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adress" name="address" placeholder="Hamra str.">
            
            <label><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="Beirut">


            <label id="zip">Zip</label>
            <input type="text" id="zip" name="zip" placeholder="0000">
              
          </div>

          <div class = "divv" >
            <h3>Payment</h3>
            <label>Accepted Cards</label>
            <div class="icons">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label>Name on Card</label>
            <input type="text" id = "nameOfcard" name="cardname" placeholder="Khaleel Mershadi" required>
            
            <label>Credit card number</label>
            <input id = "cardNb" type="text" name="cardnumber" placeholder="#### #### #### #### (4-4-4-4)" required>
            
            <label>Exp Month</label>
            <input id = "expM" type="number" name="expmonth" placeholder="1 - 12" min = "1" max = "12" required>

              
            <label>Exp Year</label>
            <input id = "expY" type="text" name="expyear" placeholder="2024" required>

            <label>Pin</label>
            <input id = "pin" type="password" name="pin" placeholder="****" required>
            <br>
            <input type="submit" name = "submit" value="Confirm Booking" class="View">            
            
        
              
          </div>
          
          
        </form>
      </div>
    



      <?php include './footer.php'?>
    


    
</body>


</html>