function Add(){
    var body = document.getElementById("review");
    var div1 = document.createElement("div");
    div1.setAttribute("class", "reviews-box");

    var div2 = document.createElement("div");
    div2.setAttribute("class", "box-top");

    var div3 = document.createElement("div");
    div3.setAttribute("class", "user");

    var div4 = document.createElement("div");
    div4.setAttribute("class", "reviews");

    var div5 = document.createElement("div");
    div5.setAttribute("class", "review-comment");

    var stars = document.createElement("i");
    stars.setAttribute=("class","fa fa-star");

    var name = document.getElementById("name");
    var rating = document.getElementById("rating");
    var message =document.getElementById("message");

    div3.innerHTML = name.value;
    div5.innerHTML = message.value;

    body.appendChild(div1);
    div1.appendChild(div2);
    div2.appendChild(div3);
    div2.appendChild(div4);
    div1.appendChild(div5);

    div4.innerHTML = rating.value +" Stars"
        
    
}