var check;
var price;
var totalPrice;
var totalDiv;
var btn;

window.addEventListener("load",start,false);

function start(){
    btn = document.getElementById("menuButton");
    btn.addEventListener("click", calculate, false);
}

function calculate(){
    var totalDiv= document.getElementById("totals");
    totalPrice= 0;
    totalDiv.innerHTML="";
    
    
    for( var i = 1; i<13; i++){
        
        var item = document.getElementById("check"+i);
        var priceItem = document.getElementById("price"+i);
        
        totalPrice += parseInt(priceItem.innerHTML)*parseInt(item.value);

    }

    totalDiv.innerHTML = totalPrice+"$";
}

