<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="Forms.css">
    <title>Document</title>
</head>
<body>
   
   
   
       <div style="text-align: center; display: flex; justify-content: center; margin: 10%;">
        <div class = "login">
       
           

        <div class="backlogin">
        
        <div class = "form">
        <h2 style="font-family: serif; font-weight: normal; margin-bottom: 5%; color: darkgoldenrod;"> Admin Log In</h2>
        
        <p><input type = "text" name = "username" placeholder = "Username" autocomplete="on" required size = "25"></p>
        <br>
         <p><input type="password" name = "password" size = "25" placeholder = "Password"></p>
       <br>
         <p><a href = "manager.php"><input type = "submit" value = "Log in" size = "25" class = "submit"></a></p>
        </div>
    
      
    </div>
    </div>
           
     </div>
       
       
     
   
    
</body>


</html>